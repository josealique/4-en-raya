var canvas = document.querySelector('#canvas');
var c = canvas.getContext('2d');
var ls = JSON.parse(localStorage.getItem("opciones"));
var opciones = {
    jugador: "red",
    jugador2: "yellow",
    turno: false,
    ganador: "",
    filas: 5,
    columnas: 5,
    circulos: [],
    tablero: []
};
if (ls){
    opciones.jugador = ls.jugador1;
    opciones.jugador2 = ls.jugador2;
    opciones.filas = ls.filas;
    opciones.columnas = ls.columnas;
    canvas.width = opciones.columnas * 100;
    canvas.height = opciones.filas * 100;
}
console.log(ls);
var circulo = function (x, y, color, c, canvas, r) {
    this.x = x;
    this.y = y;
    this.color = color;
    this.c = c;
    this.canvas = canvas;
    this.r = r;
    this.rellenado = false;

    this.draw = function (color) {
        this.color = color || '#fff';
        this.c.beginPath();
        this.c.fillStyle = this.color;
        this.c.arc(this.x, this.y, this.r, 0, Math.PI * 2);
        this.c.fill();
    }
}

iniciarTablero();


function iniciarTablero() {
    for (var i = 0; i < opciones.filas; i++) {
        opciones.tablero.push([]);
        opciones.circulos.push([]);
        for (var j = 0; j < opciones.columnas; j++) {
            opciones.circulos[i].push(new circulo(j * 100 + 50, i * 100 + 50, "white", c, canvas, 45));
            opciones.circulos[i][j].draw();
            opciones.tablero[i].push("");
        }
    }
}

canvas.addEventListener('click', function (e) {
    if (opciones.ganador){
        reiniciar();
    }
    for (var i = 0; i < opciones.tablero.length; i++) {
        for (var j = 0; j < opciones.tablero[i].length; j++) {
            var pos = {
                x: opciones.circulos[i][j].x - e.offsetX,
                y: opciones.circulos[i][j].y - e.offsetY
            };
            var distancia = Math.sqrt(pos.x * pos.x + pos.y * pos.y);

            if (distancia < 45) {
                if (!opciones.turno) {
                    opciones.turno = true;
                    pintarCirculo(opciones.tablero, opciones.circulos, opciones.jugador, j, i);
                } else {
                    opciones.turno = false;
                    pintarCirculo(opciones.tablero, opciones.circulos, opciones.jugador2, j, i);
                }
                buscarGanador(opciones.tablero);
            }
        }
    }

});

function pintarCirculo(tablero, circulos, jugador, columna, fila) {
    for (var i = tablero.length - 1; i >= 0; i--) {
        if (!circulos[i][columna].rellenado) {
            opciones.circulos[i][columna].draw(jugador);
            opciones.circulos[i][columna].rellenado = true;
            opciones.tablero[i][columna] = jugador;
            return true;
        }
    }
    return false;
};

function buscarGanador(tablero) {
    for (var fila = 0; fila < tablero.length; fila++) {
        for (var columna = 0; columna < tablero[fila].length; columna++) {
            if (fila + 4 <= tablero[fila].length) {
                comprobarVertical(fila, columna, tablero);
            }
            if (columna + 3 <= tablero.length) {
                comprobarHorizontal(fila, columna, tablero);
            }
            if (fila + 4 <= tablero[fila].length && columna >= 3) {
                comprobarDiagonalIzquierdo(fila, columna, tablero);
            }
            if (fila + 4 <= tablero[fila].length && columna + 3 <= tablero.length) {
                comprobarDiagonalDerecho(fila, columna, tablero);
            }
        }
    }
};

function comprobarVertical(fila, columna, tablero) {
    var count = 0;
    if (opciones.tablero[fila][columna] != '') {
        for (var i = 1; i < 4; i++) {
            if (opciones.tablero[fila + i][columna] != opciones.tablero[fila][columna]) {
                return;
            }
            count++;
        }
    }
    if (count == 3) {
        opciones.ganador = opciones.tablero[fila][columna];
        IdentificarGanador();
    }
};

function comprobarHorizontal(fila, columna, tablero) {
    var count = 0;
    if (opciones.tablero[fila][columna] != '') {
        for (var i = 1; i < 4; i++) {
            if (opciones.tablero[fila][columna + i] != opciones.tablero[fila][columna]) {
                return;
            }
            count++;
        }
    }
    if (count == 3) {
        opciones.ganador = opciones.tablero[fila][columna];
        IdentificarGanador();
    }
};

function comprobarDiagonalDerecho(fila, columna, tablero) {
    var count = 0;
    if (opciones.tablero[fila][columna] != '') {
        for (var i = 1; i < 4; i++) {
            if (opciones.tablero[fila + i][columna + i] != opciones.tablero[fila][columna]) {
                return;
            }
            count++;
        }
    }
    if (count == 3) {
        opciones.ganador = opciones.tablero[fila][columna];
        IdentificarGanador();
    }
};

function comprobarDiagonalIzquierdo(fila, columna, tablero) {
    var count = 0;
    if (opciones.tablero[fila][columna] != '') {
        for (var i = 1; i < 4; i++) {
            if (opciones.tablero[fila + i][columna - i] != opciones.tablero[fila][columna]) {
                return;
            }
            count++;
        }
    }
    if (count == 3) {
        opciones.ganador = opciones.tablero[fila][columna];
        IdentificarGanador();
    }
};

function dibujarOpacidad() {
    c.shadowOffsetX = 0;
    c.shadowOffsetY = 0;
    c.shadowBlur = 0;
    c.fillStyle = "rgba(255, 255, 255, 0.5)";
    c.fillRect(0, 0, canvas.width, canvas.height)
};

function dibujarTexto(text, fill, stroke) {
    dibujarOpacidad();
    c.fillStyle = fill;
    c.font = (text.length * 2) + "px " + " Arial";
    var x = (canvas.width - c.measureText(text).width) / 2,
        y = canvas.height / 2;
    c.fillText(text, x, y);
    c.font = 80 / 2 + "px " + " Arial";
    var restart = "Click to restart";
    c.fillText(restart, (canvas.width - c.measureText(restart).width) / 2, canvas.height - 8);
};

function IdentificarGanador() {
    if (opciones.ganador) {
        dibujarTexto("Ganador: " + opciones.ganador, opciones.ganador, opciones.ganador);
    }
};

function reiniciar() {
    opciones.turno = opciones.ganador === opciones.jugador;
    opciones.ganador = null;
    opciones.tablero = [];
    opciones.circulos = [];
    c.clearRect(0,0, canvas.width, canvas.height);
    pintarTablero();
    iniciarTablero(); 
}

function pintarTablero(){
    for (var i = 0; i < opciones.tablero.length; i++){
        for (var j = 0; j < opciones.tablero[i].length; j++){
            pintarCirculo(opciones.tablero, opciones.circulos, "white", i, j);
        }
    }
}